<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Cayley–Hamilton Theorem — Interactive Demo</title>
  <style>
    body{font-family:Inter, system-ui, -apple-system, 'Segoe UI', Roboto, 'Helvetica Neue', Arial; margin:24px; color:#111}
    h1{font-size:1.6rem}
    .card{border:1px solid #ddd; border-radius:8px; padding:16px; margin-bottom:16px; box-shadow:0 4px 12px rgba(0,0,0,0.03)}
    label{display:block; margin-top:8px}
    input[type=number]{width:84px}
    .matrix-input{display:grid; gap:6px}
    .row{display:flex; gap:6px}
    button{padding:8px 12px; border-radius:6px; border:1px solid #0b5; background:#e9f7ee}
    pre{background:#f8f8f8;padding:12px;border-radius:6px;overflow:auto}
    .small{font-size:0.9rem;color:#555}
  </style>
  <!-- MathJax for rendering math -->
  <script src="https://polyfill.io/v3/polyfill.min.js?features=es6"></script>
  <script id="MathJax-script" async src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-mml-chtml.js"></script>
</head>
<body>
  <h1>Cayley–Hamilton Theorem — Interactive HTML Example</h1>
  <div class="card">
    <p>The <strong>Cayley–Hamilton theorem</strong> states that every square matrix satisfies its own characteristic polynomial. If \(A\) is an \(n\times n\) matrix and \(p(\lambda)=\det(\lambda I - A)\) is its characteristic polynomial, then \(p(A)=0\) (the zero matrix).</p>
    <p class="small">This page lets you input a 2×2 or 3×3 matrix, computes the characteristic polynomial, and evaluates the polynomial at the matrix to demonstrate the theorem numerically.</p>
  </div>

  <div class="card">
    <label for="size">Matrix size:</label>
    <select id="size">
      <option value="2">2 × 2</option>
      <option value="3">3 × 3</option>
    </select>

    <div id="matrixArea" style="margin-top:12px"></div>

    <div style="margin-top:12px">
      <button id="compute">Compute characteristic polynomial & verify</button>
      <button id="reset">Reset</button>
    </div>
  </div>

  <div class="card">
    <h3>Results</h3>
    <div id="results"></div>
  </div>

  <script>
    // Utility functions for matrices (2x2 and 3x3 only)
    function createMatrixInputs(n){
      const area = document.getElementById('matrixArea');
      area.innerHTML = '';
      const container = document.createElement('div');
      container.className = 'matrix-input';
      for(let i=0;i<n;i++){
        const row = document.createElement('div');
        row.className = 'row';
        for(let j=0;j<n;j++){
          const inp = document.createElement('input');
          inp.type = 'number'; inp.step = 'any'; inp.value = (i===j?1:0); // default identity
          inp.id = `a_${i}_${j}`;
          row.appendChild(inp);
        }
        container.appendChild(row);
      }
      area.appendChild(container);
    }

    function readMatrix(n){
      const A = Array.from({length:n}, ()=>Array(n).fill(0));
      for(let i=0;i<n;i++) for(let j=0;j<n;j++){
        const v = parseFloat(document.getElementById(`a_${i}_${j}`).value || 0);
        A[i][j] = v;
      }
      return A;
    }

    function matMul(A,B){
      const n=A.length; const C=Array.from({length:n}, ()=>Array(n).fill(0));
      for(let i=0;i<n;i++) for(let j=0;j<n;j++) for(let k=0;k<n;k++) C[i][j]+=A[i][k]*B[k][j];
      return C;
    }
    function matAdd(A,B){ const n=A.length; const C=Array.from({length:n}, ()=>Array(n).fill(0)); for(let i=0;i<n;i++) for(let j=0;j<n;j++) C[i][j]=A[i][j]+B[i][j]; return C; }
    function matScale(A,s){ const n=A.length; const C=Array.from({length:n}, ()=>Array(n).fill(0)); for(let i=0;i<n;i++) for(let j=0;j<n;j++) C[i][j]=A[i][j]*s; return C; }
    function identity(n){ const I=Array.from({length:n}, (_,i)=>Array.from({length:n}, (_,j)=> i===j?1:0)); return I; }
    function matEqual(A,B,tol=1e-8){ const n=A.length; for(let i=0;i<n;i++) for(let j=0;j<n;j++) if(Math.abs(A[i][j]-B[i][j])>tol) return false; return true; }

    // characteristic polynomial and evaluation for 2x2 and 3x3
    function charPoly2x2(A){
      // For 2x2 A = [[a,b],[c,d]]
      const a = A[0][0], b=A[0][1], c=A[1][0], d=A[1][1];
      // p(λ) = λ^2 - (trace) λ + det
      const tr = a + d;
      const det = a*d - b*c;
      return {coeffs: [1, -tr, det], polyString:`\(\lambda^{2} - (${tr.toFixed(4)})\lambda + (${det.toFixed(4)})\)`};
    }

    function charPoly3x3(A){
      // Using coefficients from characteristic polynomial p(λ)=λ^3 - s1 λ^2 + s2 λ - s3
      // where s1 = trace(A)
      // s2 = sum of principal minors of size 2
      // s3 = det(A)
      const a11 = A[0][0], a12=A[0][1], a13=A[0][2];
      const a21 = A[1][0], a22=A[1][1], a23=A[1][2];
      const a31 = A[2][0], a32=A[2][1], a33=A[2][2];
      const s1 = a11 + a22 + a33;
      // principal minors of size 2
      const m12 = a11*a22 - a12*a21;
      const m13 = a11*a33 - a13*a31;
      const m23 = a22*a33 - a23*a32;
      const s2 = m12 + m13 + m23;
      const s3 = (
        a11*(a22*a33 - a23*a32) - a12*(a21*a33 - a23*a31) + a13*(a21*a32 - a22*a31)
      );
      // p(λ) = λ^3 - s1 λ^2 + s2 λ - s3
      return {coeffs: [1, -s1, s2, -s3], polyString:`\\(\\lambda^{3} - (${s1.toFixed(4)})\\lambda^{2} + (${s2.toFixed(4)})\\lambda - (${s3.toFixed(4)})\\)`};
    }

    function evalPolyAtMatrix(coeffs, A){
      // coeffs are [c0, c1, c2, ...] for descending powers, e.g. [1, -s1, s2, -s3]
      // We'll evaluate using Horner's method: p(A) = (((c0*A + c1*I)*A + c2*I)*A + ...)
      const n = A.length;
      let result = Array.from({length:n}, ()=>Array(n).fill(0)); // start at zero
      let acc = Array.from({length:n}, ()=>Array(n).fill(0));
      // Horner: start with leading coefficient * I
      acc = matScale(identity(n), coeffs[0]);
      for(let k=1;k<coeffs.length;k++){
        acc = matMul(acc, A);
        if(Math.abs(coeffs[k])>0) acc = matAdd(acc, matScale(identity(n), coeffs[k]));
      }
      return acc;
    }

    function matrixToString(A){ return A.map(row=>row.map(v=>v.toFixed(6)).join('\t')).join('\n'); }

    // UI bindings
    const sizeSel = document.getElementById('size');
    createMatrixInputs(2);
    sizeSel.addEventListener('change', ()=> createMatrixInputs(parseInt(sizeSel.value)));
    document.getElementById('reset').addEventListener('click', ()=> createMatrixInputs(parseInt(sizeSel.value)));

    document.getElementById('compute').addEventListener('click', ()=>{
      const n = parseInt(sizeSel.value);
      const A = readMatrix(n);
      let polyInfo;
      if(n===2) polyInfo = charPoly2x2(A);
      else polyInfo = charPoly3x3(A);

      const pA = evalPolyAtMatrix(polyInfo.coeffs, A);
      const isZero = matEqual(pA, Array.from({length:n}, ()=>Array(n).fill(0)));

      const res = document.getElementById('results');
      res.innerHTML = '';
      const s = document.createElement('div');
      s.innerHTML = `<p><strong>Input matrix A:</strong></p><pre>${matrixToString(A)}</pre>`;
      const polyDiv = document.createElement('div');
      polyDiv.innerHTML = `<p><strong>Characteristic polynomial \(p(\lambda)\):</strong> ${polyInfo.polyString}</p>`;
      const evalDiv = document.createElement('div');
      evalDiv.innerHTML = `<p><strong>Computed \(p(A)\):</strong></p><pre>${matrixToString(pA)}</pre>`;
      const verdict = document.createElement('p');
      verdict.innerHTML = isZero ? '<strong>Verification:</strong> p(A) is (numerically) the zero matrix — Cayley–Hamilton verified.' : '<strong>Verification:</strong> p(A) is NOT the zero matrix (within numerical tolerance).';

      res.appendChild(s); res.appendChild(polyDiv); res.appendChild(evalDiv); res.appendChild(verdict);

      // Typeset math with MathJax
      if(window.MathJax) MathJax.typesetPromise();
    });

  </script>

  <hr style="margin-top:28px" />
  <p class="small">Notes: This is a numeric demonstration for 2×2 and 3×3 matrices. The code computes the characteristic polynomial using exact algebraic formulas for these sizes, then evaluates the polynomial on the matrix numerically. For larger matrices a symbolic determinant routine would be required.</p>
</body>
</html>